using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2")]
[assembly: InternalsVisibleTo("neo.UnitTests")]
[assembly: InternalsVisibleTo("neodebug-3-adapter")]
