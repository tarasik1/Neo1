using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Neo.Json.UnitTests")]
